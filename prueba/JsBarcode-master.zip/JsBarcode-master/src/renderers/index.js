import canvas from './canvas.js';
import svg from './svg.js';

export default {
  canvas,
  svg
};
